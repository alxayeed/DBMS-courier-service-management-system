<!DOCTYPE html>
<html>
<title>Courier</title>
<head></head>

<style>

table, th, td {
    border: 2px solid black;
    background-color: white;
    border-collapse: collapse;
}

th,td {
  padding: 20px;
}


header,footer {
    padding:;
    color: black;
    background-color: ; ;
    clear: left;
    text-align: center;
}

body{
    background-image:url("1.jpg")  ;
    height:100%;
}
ul {
  float:left;
  margin-left:285px;
  margin-bottom:400px;
}
ul li{
 display:inline-block;
 padding-left:15px;
 font-size:30px;


}
ul li a{
text-decoration:none;
}



li a, .dropbtn {
    display: inline-block;
    color: black ;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover, .dropdown:hover .dropbtn {
    background-color: white;
}

li.dropdown {
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.dropdown-content a:hover {background-color: red ;}

.dropdown:hover .dropdown-content {
    display: block;
}

</style>
<body>


<center>
<ul >
<li style="width=280px;height:40px ;" ><b><a href="Home.html">HOME</a></b></li>
<!--<li style="width=280px;height:40px ;" ><b><a href="InsertS.html">INSERT</a></b></li> -->
 <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn"><b>INSERT</b></a>
    <div class="dropdown-content">
      <a href="InsertS.html">Sender Information</a>
      <a href="InsertR.html">Reciever Information</a>
      <a href="InsertB.html">Branch Information</a>
    </div>
  </li>
<li style="width=280px;height:40px;"><b><a href="Search.html"> SEARCH</a></b></li>
<!-- <li style="width=280px;height:40px;display=inline-block;"><a href="View.html"><b>VIEW</b></a></li> -->
<li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn"><b>VIEW</b></a>
    <div class="dropdown-content">
      <a href="ViewS.php">Sender Information</a>
      <a href="ViewR.php">Reciever Information</a>
      <a href="ViewB.php">Branch Information</a>
    </div>
  </li>
<br><br><br>
<h1><bold><big></big> </bold></h1>
<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "cs_db";
	// Create connection
	$conn = new mysqli($servername, $username, $password,$dbname);

	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}
	//echo "Connected successfully\n";

		$sql = "SELECT * FROM output";

		$result = $conn->query($sql);
		echo"<center><table border=1><tr><th>Product Tag</th><th>Sender Name </th><th>Sender Contact no</th><th>Reciever Name</th><th>Reciever Contact no</th><th>Reciever Location</th><th>Bill</th><th>action</th></tr>";

		if ($result->num_rows > 0) {
			while ($row = $result->fetch_assoc()) {
				// HERE EVERY TABLE DATA WILL CONTAIN DIFFRENT ID TO PRINT
				echo "<tr><td id='a".$row['ptag']."'>".$row['ptag']."</td><td id='b".$row['ptag']."'>".$row['sname']."</td>";
				echo "<td id='c".$row['ptag']."'>".$row['scon']."</td><td id='d".$row['ptag']."'>".$row['rname']."</td>";
				echo "<td id='e".$row['ptag']."'>".$row['rcon']."</td><td id='f".$row['ptag']."'>".$row['rloc']."</td>";
				echo "<td id='g".$row['ptag']."'>".$row['bill']."</td>";

				// PDF BUTTON CREATION
				echo "<td><form action='' method='GET'><input type='submit' name='print".$row['ptag']."' value='Print'></form></td></tr>";
	if(isset($_GET['print'.$row['ptag']])){

					echo "<script>
echo "<div class="sadia" style=" height:670px;width:500px;border:3px solid black;background-color:white;margin-left:200px;margin-right:200px;margin-bottom:50px;" >";
					var mywindow = window.open('', 'PRINT', 'height=400,width=600');
					mywindow.document.write('<html><head><title>' + document.title  + '</title>');
					mywindow.document.write('</head><body><center>');
					mywindow.document.write('<h1>' + 'Continental Courier Service'  + '</h1><table >');
					mywindow.document.write('<h3>' + '(ABDULLAH AL SAYEED)'  + '</h3>');
					mywindow.document.write('</center>');
          mywindow.document.write('<td>')
					mywindow.document.write('Product tag  &emsp;  &emsp;&emsp;&emsp;&emsp;&emsp;: &emsp;')
					mywindow.document.write(document.getElementById('a".$row['ptag']."').innerHTML);
					mywindow.document.write('<br><br> ');
          mywindow.document.write('Sender Name  &emsp; &emsp;&emsp;&emsp;&emsp;: &emsp;')
					mywindow.document.write(document.getElementById('b".$row['ptag']."').innerHTML);
					mywindow.document.write('<br><br');
					mywindow.document.write('Sender Contact No &emsp;  &emsp;&emsp;&emsp;&emsp;&emsp;: &emsp; ')
					mywindow.document.write(document.getElementById('c".$row['ptag']."').innerHTML);
					mywindow.document.write('<br><br>  ');
          mywindow.document.write('Sender Contact No &emsp;&emsp;&emsp;:&emsp;  ')
					mywindow.document.write(document.getElementById('c".$row['ptag']."').innerHTML);
					mywindow.document.write('<br><br>  ');
          mywindow.document.write('From &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; : &emsp; Mirpur ')

          	mywindow.document.write('<br><br>  ');
					mywindow.document.write('Reciever Name &emsp;&emsp;&emsp;&emsp; :&emsp; ')
					mywindow.document.write(document.getElementById('d".$row['ptag']."').innerHTML);
					mywindow.document.write('<br> <br>');
					mywindow.document.write('Reciever Contact No &emsp; &emsp; :&emsp; ')
					mywindow.document.write(document.getElementById('e".$row['ptag']."').innerHTML);
					mywindow.document.write('<br> <br> ');
					mywindow.document.write('To &emsp;&emsp;&emsp;  &emsp;&emsp;&emsp;&emsp;&emsp;&emsp; :&emsp; ')
					mywindow.document.write(document.getElementById('f".$row['ptag']."').innerHTML);
					mywindow.document.write('<br> <br>');
					mywindow.document.write('------------------------------------------------------------------  ')
					mywindow.document.write(' <br> ');
					mywindow.document.write('Service Charge &emsp; : &emsp; ')
					mywindow.document.write(document.getElementById('g".$row['ptag']."').innerHTML);
					mywindow.document.write(' <br> ');
					mywindow.document.write('VAT   (10%) &emsp; &emsp;&emsp;:   &emsp; 80 ')
					mywindow.document.write(' <br> ');
          mywindow.document.write('------------------------------------------------------------------  ')
          mywindow.document.write(' <br> ');
					mywindow.document.write('Total Bill &emsp; &emsp;  &emsp; : &emsp;880 ')
					mywindow.document.write(' <br><br> ');
          mywindow.document.write(' <br><br> ');
          mywindow.document.write(' &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp;----------------------------------------  ')
          mywindow.document.write(' <br> ');
					mywindow.document.write(' &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; Signature: ')
					mywindow.document.write('<td>')
					mywindow.document.write('</table></body></html></center>');
					mywindow.document.close(); // necessary for IE >= 10
					mywindow.focus(); // necessary for IE >= 10*/
echo "</div>";
					mywindow.print();
					mywindow.close();
					history.back(); // IT WILL TAKE YOU BAKE PAGE
					</script>";
				}





			}echo"</table></center>";
		}else{
				echo "No search found!!!";
		}
	$conn->close();
	 ?>

	 </body>
	 </html>
