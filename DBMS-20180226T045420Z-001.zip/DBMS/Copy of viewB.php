<!DOCTYPE html>
<html>
<title>Courier</title>
<head></head>

<style>

table, th, td {
    border: 2px solid black;
    background-color: white;
    border-collapse: collapse;
}

th,td {
  padding: 20px;
}


header,footer {
    padding:;
    color: black;
    background-color: ; ;
    clear: left;
    text-align: center;
}

body{
    background-image:url("1.jpg")  ;
    height:100%;
}
ul {
  float:left;
  margin-left:285px;
  margin-bottom:400px;
}
ul li{
 display:inline-block;
 padding-left:15px;
 font-size:30px;


}
ul li a{
text-decoration:none;
}



li a, .dropbtn {
    display: inline-block;
    color: black ;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover, .dropdown:hover .dropbtn {
    background-color: white;
}

li.dropdown {
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.dropdown-content a:hover {background-color: red ;}

.dropdown:hover .dropdown-content {
    display: block;
}

</style>
<body>


<center>
<ul >
<li style="width=280px;height:40px ;" ><b><a href="Home.html">HOME</a></b></li>
<!--<li style="width=280px;height:40px ;" ><b><a href="InsertS.html">INSERT</a></b></li> -->
 <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn"><b>INSERT</b></a>
    <div class="dropdown-content">
      <a href="InsertS.html">Sender Information</a>
      <a href="InsertR.html">Reciever Information</a>
      <a href="InsertB.html">Branch Information</a>
    </div>
  </li>
<li style="width=280px;height:40px;"><b><a href="Search.html"> SEARCH</a></b></li>
<!-- <li style="width=280px;height:40px;display=inline-block;"><a href="View.html"><b>VIEW</b></a></li> -->
<li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn"><b>VIEW</b></a>
    <div class="dropdown-content">
      <a href="ViewS.php">Sender Information</a>
      <a href="ViewR.php">Reciever Information</a>
      <a href="ViewB.php">Branch Information</a>
    </div>
  </li>
<br><br><br>
<h1><bold><big>Update Branch Information</big> </bold></h1>


<?php
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "cs_db";
  // Create connection
  $conn = new mysqli($servername, $username, $password,$dbname);

  // Check connection
  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }
  //echo "Connected successfully\n";

    $sql = "SELECT * FROM branch";

    $result = $conn->query($sql);
    echo"<table align=center><tr><th>Branch Code  </th><th>Location</th><th>Executive name</th><th>Contact No </th><th colspan='3'> Action </th></tr>";

    if ($result->num_rows > 0) {
      while ($row = $result->fetch_assoc()) {
        // HERE EVERY TABLE DATA WILL CONTAIN DIFFRENT ID TO PRINT
        echo "<tr><td id='b".$row['b_id']."'>".$row['b_id']."</td>";
        echo "<td id='c".$row['b_id']."'>".$row['bLoc']."</td><td id='d".$row['b_id']."'>".$row['bEx']."</td>";
        echo "<td id='e".$row['b_id']."'>".$row['bCon']."</td>";

        // EDIT BUTTON CREATION
        echo "<td><form action='' method='GET'><input type='submit' name=".$row['b_id']." value='Edit'></form></td>";
        // DELETE BUTTON CREATION
        echo "<td><form action='' method='GET'><input type='submit' name='delete".$row['b_id']."' value='Delete'></form></td>";
        // PDF BUTTON CREATION
        echo "<td><form action='' method='GET'><input type='submit' name='print".$row['b_id']."' value='Print'></form></td></tr>";

        // UPDATE CODE STARTS FROM HERE
        if(isset($_GET[$row['b_id']])){
          echo"<form action='' method='POST'><div class='p' id='close'>";// CLASS P IS USED TO DECORATION AND ID CLOSE IS USED TO CLOSE THE POPUP PAGE
          
          echo "Branch Code</br>";
          echo"<input type='text' name='b_id' value=".$row['b_id']." required></br>";
          echo "Location</br>";
          echo "<input type='text' name='bLoc' value=".$row['bLoc']."></br>";
          echo "Executive Name </br>";
          echo "<input type='text' name='bEx' value=".$row['bEx']."></br>";
          echo "Contact</br>";
          echo "<input type='text' name='bCon' value=".$row['bCon']."></br>";
          echo"<input type='submit' name = 'submit' value='Update'>";
          echo"<input type='submit' name = 'cancle' value='Cancel'></br></br>";
          echo "</div></form>";

          if(isset($_POST['submit'])){
          
            $name = $_POST["b_id"];
            $tag = $_POST["bLoc"];
            $cont = $_POST["bEx"];
            $locn = $_POST["bCon"];


            $ssql = "UPDATE branch SET  b_id='$name', bLoc='$tag', bEx='$cont', bCon='$locn'
            WHERE b_id=".$row['b_id']."";
            
            if ($conn->query($ssql) === TRUE) {
            echo "<meta http-equiv='refresh' content='0'>";
            echo "<script type='text/javascript'>alert('Submitted successfully!')</script>";
            } else {
            echo "Upadate Unsucessful". $conn->error;
            }

          }
          if(isset($_POST['cancle'])){
            echo "<script>document.getElementById('close').style.display='none'</script>";
          }
        }

        // DELETE CODE STARTS FORM HERE
        if(isset($_GET['delete'.$row['b_id']])){
          $delete = "DELETE FROM branch WHERE b_id=".$row['b_id']."";
          if ($conn->query($delete) === TRUE) {
          echo "<script type='text/javascript'>alert('Deleted successfully!')</script>";
          echo "<meta http-equiv='refresh' content='0'>";
           // THIS IS FOR AUTO REFRESH CURRENT PAGE
          } else {
          echo "Delete Unsucessful". $conn->error;
          }
        }

        // PDF STARTS FROM HERE
        if(isset($_GET['print'.$row['b_id']])){

          echo "<script>
          var mywindow = window.open('', 'PRINT', 'height=400,width=600');
          mywindow.document.write('<html><head><title>' + document.title  + '</title>');
          mywindow.document.write('</head><body >');
          mywindow.document.write('<h1>' + 'Branch Information'  + '</h1>')
          mywindow.document.write(document.getElementById('b".$row['b_id']."').innerHTML);
          mywindow.document.write(' -- ');
          mywindow.document.write(document.getElementById('c".$row['b_id']."').innerHTML);
          mywindow.document.write(' -- ');
          mywindow.document.write(document.getElementById('d".$row['b_id']."').innerHTML);
          mywindow.document.write(' -- ');
          mywindow.document.write(document.getElementById('e".$row['b_id']."').innerHTML);
          mywindow.document.write(document.getElementById('f".$row['b_id']."').innerHTML);
          mywindow.document.write('</body></html>');
          mywindow.document.close(); // necessary for IE >= 10
          mywindow.focus(); // necessary for IE >= 10*/

          mywindow.print();
          mywindow.close();
          history.back(); // IT WILL TAKE YOU BAKE PAGE
          </script>";
        }





      }echo"</table>";
    }
  $conn->close();
   ?>



<button><a href="printB.php">PRINT</a></button>
<footer><h1>Continental Courier Service</h1></footer>


</ul>
</center>
</body>
</html>
