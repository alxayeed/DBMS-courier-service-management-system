<!DOCTYPE html>
<html>
<title>Courier</title>
<head></head>

<style>

table, th, td {
    border: 1px solid black;

}


header,footer {
    padding:;
    color: black;
    background-color: ; ;
    clear: left;
    text-align: center;
}

body{
    background-image:url("1.jpg")  ;
    height:100%;
}
ul {
  float:left;
  margin-left:285px;
  margin-bottom:400px;
}
ul li{
 display:inline-block;
 padding-left:15px;
 font-size:30px;


}
ul li a{
text-decoration:none;
}

li a, .dropbtn {
    display: inline-block;
    color: black ;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover, .dropdown:hover .dropbtn {
    background-color: white;
}

li.dropdown {
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.dropdown-content a:hover {background-color: red ;}

.dropdown:hover .dropdown-content {
    display: block;
}

</style>
<body>


<center>
<ul >
<li style="width=280px;height:40px ;" ><b><a href="Home.html">HOME</a></b></li>
<!--<li style="width=280px;height:40px ;" ><b><a href="InsertS.html">INSERT</a></b></li> -->
 <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn"><b>INSERT</b></a>
    <div class="dropdown-content">
      <a href="InsertS.html">Sender Information</a>
      <a href="InsertR.html">Reciever Information</a>
      <a href="InsertB.html">Branch Information</a>
    </div>
  </li>
<li style="width=280px;height:40px;"><b><a href="Search.html"> SEARCH</a></b></li>
<!-- <li style="width=280px;height:40px;display=inline-block;"><a href="View.html"><b>VIEW</b></a></li> -->
<li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn"><b>VIEW</b></a>
    <div class="dropdown-content">
      <a href="ViewS.php">Sender Information</a>
      <a href="ViewR.php">Reciever Information</a>
      <a href="ViewB.php">Branch Information</a>
    </div>
  </li>
<br><br><br>
<h1><bold><big>Sender Information</big> </bold></h1>



<?php

$link = mysqli_connect("localhost", "root", "", "cs_db");

// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

// Escape user inputs for security
$name = mysqli_real_escape_string($link, $_REQUEST['name']);
$tag = mysqli_real_escape_string($link, $_REQUEST['p_tag']);
$contact = mysqli_real_escape_string($link, $_REQUEST['contact']);
$location = mysqli_real_escape_string($link, $_REQUEST['location']);
$bill = mysqli_real_escape_string($link, $_REQUEST['bill']);

// attempt insert query execution
$sql = "INSERT INTO sender (name,p_tag,contact,location,bill) VALUES ('$name', '$tag', '$contact','$location','$bill')";
if(mysqli_query($link, $sql)){
    echo "<h1>Records added successfully</h1>.";
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}

// close connection
mysqli_close($link);

?>

</ul>

</table>
</body>
</html>
