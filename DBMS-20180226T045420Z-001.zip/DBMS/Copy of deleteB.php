<?php

//Connecting to the mysql
$con=mysqli_connect("localhost","root","");

//Select database
 mysqli_select_db($con, 'cs_db');

//Select query
$sql = "DELETE FROM branch WHERE b_id='$_GET[b_id]'";

//Execute the query
if (mysqli_query($con, $sql))
   header("refresh:1; url=viewB.php");
else
   echo"Not Deleted";
?>
