<style>
// THIS STYLE IS IMPORTANT FOR POPUP UPDATE PAGE 
	.p{
	background: #f5f3f3;
	z-index: 9999;
	height: 300px;
	width: 400px;
	position: absolute;
	margin-left: 20%;
	margin-top: -60px;
	padding-bottom: 35px;
	border: 1px dotted green;
	padding-top: 15px;
}
</style>






<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "db_abc";
	// Create connection
	$conn = new mysqli($servername, $username, $password,$dbname);

	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}
	//echo "Connected successfully\n";

		$sql = "SELECT * FROM reader";

		$result = $conn->query($sql);
		echo"<table><tr><th>ID</th><th>Name</th><th>Gender</th><th>Department</th><th>Program</th><th>Phone Number</th><th>Edit</th><th>Delete</th><th>Print</th></tr>";

		if ($result->num_rows > 0) {
			while ($row = $result->fetch_assoc()) {
				// HERE EVERY TABLE DATA WILL CONTAIN DIFFRENT ID TO PRINT
				echo "<tr><td id='a".$row['id']."'>".$row['id']."</td><td id='b".$row['id']."'>".$row['name']."</td>";
				echo "<td id='c".$row['id']."'>".$row['gender']."</td><td id='d".$row['id']."'>".$row['department']."</td>";
				echo "<td id='e".$row['id']."'>".$row['program']."</td><td id='f".$row['id']."'>".$row['phone_num']."</td>";

				// EDIT BUTTON CREATION
				echo "<td><form action='' method='GET'><input type='submit' name=".$row['id']." value='Edit'></form></td>";
				// DELETE BUTTON CREATION
				echo "<td><form action='' method='GET'><input type='submit' name='delete".$row['id']."' value='Delete'></form></td>";
				// PDF BUTTON CREATION
				echo "<td><form action='' method='GET'><input type='submit' name='print".$row['id']."' value='Print'></form></td></tr>";

				// UPDATE CODE STARTS FROM HERE
				if(isset($_GET[$row['id']])){
					echo"<form action='' method='POST'><div class='p' id='close'>";// CLASS P IS USED TO DECORATION AND ID CLOSE IS USED TO CLOSE THE POPUP PAGE
					echo"Update Information</br></br>";
					echo "ID: <input type='text' name='id' value=".$row['id'].">";
					echo "</br></br>";
					echo "Name: <input type='text' name='name' value=".$row['name'].">";
					echo "</br></br>";
					echo "Gender: <input type='text' name='gender' value=".$row['gender'].">";
					echo "</br></br>";
					echo "Department: <input type='text' name='department' value=".$row['department'].">";
					echo "</br></br>";
					echo "Program: <input type='text' name='programs' value=".$row['program'].">";
					echo "</br></br>";
					echo "Phone Num: <input type='text' name='phoneNumber' value=".$row['phone_num'].">";
					echo "</br></br>";

					echo"<input type='submit' name = 'submit' value='Update'>";
					echo"<input type='submit' name = 'cancle' value='Cancle'>";
					echo "</div></form>";

					if(isset($_POST['submit'])){
						$id = $_POST["id"];
						$name = $_POST["name"];
						$gender = $_POST["gender"];
						$departments = $_POST["department"];
						$programs = $_POST["programs"];
						$phoneNumber = $_POST["phoneNumber"];

						$ssql = "UPDATE reader SET id='$id', name='$name', gender='$gender', department='$departments', program='$programs', phone_num='$phoneNumber'
						WHERE id=".$row['id']."";
						
						if ($conn->query($ssql) === TRUE) {
						echo "<script type='text/javascript'>alert('Submitted successfully!')</script>";
						} else {
						echo "Upadate Unsucessful". $conn->error;
						}

					}
					if(isset($_POST['cancle'])){
						echo "<script>document.getElementById('close').style.display='none'</script>";
					}
				}

				// DELETE CODE STARTS FORM HERE
				if(isset($_GET['delete'.$row['id']])){
					$delete = "DELETE FROM reader WHERE id=".$row['id']."";
					if ($conn->query($delete) === TRUE) {
					echo "<script type='text/javascript'>alert('Deleted successfully!')</script>";
					echo "<meta http-equiv='refresh' content='0'>"; // THIS IS FOR AUTO REFRESH CURRENT PAGE
					} else {
					echo "Delete Unsucessful". $conn->error;
					}
				}

				// PDF STARTS FROM HERE
				if(isset($_GET['print'.$row['id']])){

					echo "<script>
					var mywindow = window.open('', 'PRINT', 'height=400,width=600');
					mywindow.document.write('<html><head><title>' + document.title  + '</title>');
					mywindow.document.write('</head><body >');
					mywindow.document.write('<h1>' + 'Reader Information'  + '</h1>');
					mywindow.document.write(document.getElementById('a".$row['id']."').innerHTML);
					mywindow.document.write(' -- ');
					mywindow.document.write(document.getElementById('b".$row['id']."').innerHTML);
					mywindow.document.write(' -- ');
					mywindow.document.write(document.getElementById('c".$row['id']."').innerHTML);
					mywindow.document.write(' -- ');
					mywindow.document.write(document.getElementById('d".$row['id']."').innerHTML);
					mywindow.document.write(' -- ');
					mywindow.document.write(document.getElementById('e".$row['id']."').innerHTML);
					mywindow.document.write(' -- ');
					mywindow.document.write(document.getElementById('f".$row['id']."').innerHTML);
					mywindow.document.write('</body></html>');
					mywindow.document.close(); // necessary for IE >= 10
					mywindow.focus(); // necessary for IE >= 10*/

					mywindow.print();
					mywindow.close();
					history.back(); // IT WILL TAKE YOU BAKE PAGE
					</script>";
				}





			}echo"</table>";
		}else{
				echo "No search found!!!";
		}
	$conn->close();
	 ?>
