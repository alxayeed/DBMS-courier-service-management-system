<?php
$id =$_REQUEST['name'];

if(isset($_POST['submit'])){
$hostname = "localhost";
$username = "root";
$password = "";
$dbname = "cs_db";

$conn = new mysqli($hostname,$username,$password,$dbname);

if($conn->connect_error) {
    die("Connection Fail".$conn->connect_error);
}

 $name = $_POST['name'];
 $tag = $_POST['p_tag'];


$sql = "UPDATE sender SET name='$_POST[name]', tag='$_POST[p_tag]' WHERE name='$name'";

if (($conn->query($sql) == TRUE ) && ($name != ""  && $tag != "")) {
	echo "Updated Successfully";

}
else{
     if ($name == "" && $tag == "" ) {
         echo "Please input your values! ";
    }else {
         echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
}
?>
