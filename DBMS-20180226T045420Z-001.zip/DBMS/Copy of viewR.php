<!DOCTYPE html>
<html>
<title>Courier</title>
<head></head>

<style>

table, th, td {
    border: 2px solid black;
    background-color: white;
    border-collapse: collapse;
}

th,td {
  padding: 20px;
}


header,footer {
    padding:;
    color: black;
    background-color: ; ;
    clear: left;
    text-align: center;
}

body{
    background-image:url("1.jpg")  ;
    height:100%;
}
ul {
  float:left;
  margin-left:285px;
  margin-bottom:400px;
}
ul li{
 display:inline-block;
 padding-left:15px;
 font-size:30px;


}
ul li a{
text-decoration:none;
}



li a, .dropbtn {
    display: inline-block;
    color: black ;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover, .dropdown:hover .dropbtn {
    background-color: white;
}

li.dropdown {
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.dropdown-content a:hover {background-color: red ;}

.dropdown:hover .dropdown-content {
    display: block;
}

</style>
<body>


<center>
<ul >
<li style="width=280px;height:40px ;" ><b><a href="Home.html">HOME</a></b></li>
<!--<li style="width=280px;height:40px ;" ><b><a href="InsertS.html">INSERT</a></b></li> -->
 <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn"><b>INSERT</b></a>
    <div class="dropdown-content">
      <a href="InsertS.html">Sender Information</a>
      <a href="InsertR.html">Reciever Information</a>
      <a href="InsertB.html">Branch Information</a>
    </div>
  </li>
<li style="width=280px;height:40px;"><b><a href="Search.html"> SEARCH</a></b></li>
<!-- <li style="width=280px;height:40px;display=inline-block;"><a href="View.html"><b>VIEW</b></a></li> -->
<li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn"><b>VIEW</b></a>
    <div class="dropdown-content">
      <a href="ViewS.php">Sender Information</a>
      <a href="ViewR.php">Reciever Information</a>
      <a href="ViewB.php">Branch Information</a>
    </div>
  </li>
<br><br><br>
<h1><bold><big>Reciever Information</big> </bold></h1>

<?php
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "cs_db";
  // Create connection
  $conn = new mysqli($servername, $username, $password,$dbname);

  // Check connection
  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }
  //echo "Connected successfully\n";

    $sql = "SELECT * FROM reciever";

    $result = $conn->query($sql);
    echo"<table align=center><tr><th>Sender Name</th><th>Product Tag</th><th>Contact Number</th><th>Location</th><th colspan='3'> Action </th></tr>";

    if ($result->num_rows > 0) {
      while ($row = $result->fetch_assoc()) {
        // HERE EVERY TABLE DATA WILL CONTAIN DIFFRENT ID TO PRINT
        echo "<tr><td id='b".$row['id']."'>".$row['name']."</td>";
        echo "<td id='c".$row['id']."'>".$row['p_tag']."</td><td id='d".$row['id']."'>".$row['contact']."</td>";
        echo "<td id='e".$row['id']."'>".$row['location']."</td>";

        // EDIT BUTTON CREATION
        echo "<td><form action='' method='GET'><input type='submit' name=".$row['id']." value='Edit'></form></td>";
        // DELETE BUTTON CREATION
        echo "<td><form action='' method='GET'><input type='submit' name='delete".$row['id']."' value='Delete'></form></td>";
        // PDF BUTTON CREATION
        echo "<td><form action='' method='GET'><input type='submit' name='print".$row['id']."' value='Print'></form></td></tr>";

        // UPDATE CODE STARTS FROM HERE
        if(isset($_GET[$row['id']])){
          echo"<form action='' method='POST'><div class='p' id='close'>";// CLASS P IS USED TO DECORATION AND ID CLOSE IS USED TO CLOSE THE POPUP PAGE
          echo"Update Information</br></br>";
          echo "Name</br>";
          echo"<input type='text' name='name' value=".$row['name']." required></br>";
          echo "Product Tag</br>";
          echo "<input type='text' name='p_tag' value=".$row['p_tag']."></br>";
          echo "Contact</br>";
          echo "<input type='text' name='contact' value=".$row['contact']."></br>";
          echo "Location</br>";
          echo "<input type='text' name='location' value=".$row['location']."></br>";
          echo"<input type='submit' name = 'submit' value='Update'>";
          echo"<input type='submit' name = 'cancle' value='Cancel'></br></br>";
          echo "</div></form>";

          if(isset($_POST['submit'])){

            $name = $_POST["name"];
            $tag = $_POST["p_tag"];
            $cont = $_POST["contact"];
            $locn = $_POST["location"];


            $ssql = "UPDATE reciever SET  name='$name', p_tag='$tag', contact='$cont', location='$locn'
            WHERE id=".$row['id']."";

            if ($conn->query($ssql) === TRUE) {
            echo "<script type='text/javascript'>alert('Submitted successfully!')</script>";
            } else {
            echo "Upadate Unsucessful". $conn->error;
            }

          }
          if(isset($_POST['cancle'])){
            echo "<script>document.getElementById('close').style.display='none'</script>";
          }
        }

        // DELETE CODE STARTS FORM HERE
        if(isset($_GET['delete'.$row['id']])){
          $delete = "DELETE FROM reciever WHERE id=".$row['id']."";
          if ($conn->query($delete) === TRUE) {
          echo "<script type='text/javascript'>alert('Deleted successfully!')</script>";
          echo "<meta http-equiv='refresh' content='0'>"; // THIS IS FOR AUTO REFRESH CURRENT PAGE
          } else {
          echo "Delete Unsucessful". $conn->error;
          }
        }

        // PDF STARTS FROM HERE
        if(isset($_GET['print'.$row['id']])){

          echo "<script>
          var mywindow = window.open('', 'PRINT', 'height=400,width=600');
          mywindow.document.write('<html><head><title>' + document.title  + '</title>');
          mywindow.document.write('</head><body >');
          mywindow.document.write('<h1>' + 'Receiver Information'  + '</h1>')
          mywindow.document.write(document.getElementById('b".$row['id']."').innerHTML);
          mywindow.document.write(' -- ');
          mywindow.document.write(document.getElementById('c".$row['id']."').innerHTML);
          mywindow.document.write(' -- ');
          mywindow.document.write(document.getElementById('d".$row['id']."').innerHTML);
          mywindow.document.write(' -- ');
          mywindow.document.write(document.getElementById('e".$row['id']."').innerHTML);
          mywindow.document.write(document.getElementById('f".$row['id']."').innerHTML);
          mywindow.document.write('</body></html>');
          mywindow.document.close(); // necessary for IE >= 10
          mywindow.focus(); // necessary for IE >= 10*/

          mywindow.print();
          mywindow.close();
          history.back(); // IT WILL TAKE YOU BAKE PAGE
          </script>";
        }





      }echo"</table>";
    }else{
        echo "No search found!!!";
    }
  $conn->close();
   ?>

<BUTTON><a href="printR.php">PRINT</a></b></BUTTON>
<footer><h1>Continental Courier Service</h1></footer>

</ul>
</center>
</body>
</html>
