<!DOCTYPE html>
<html>
<title>Courier</title>
<head></head>

<style>

table, th, td {
    border: 2px solid black;
    background-color: white;
    border-collapse: collapse;
}

th,td {
  padding: 20px;
}


header,footer {
    padding:;
    color: black;
    background-color: ; ;
    clear: left;
    text-align: center;
}

body{
    background-image:url("1.jpg")  ;
    height:100%;
}
ul {
  float:left;
  margin-left:285px;
  margin-bottom:400px;
}
ul li{
 display:inline-block;
 padding-left:15px;
 font-size:30px;


}
ul li a{
text-decoration:none;
}



li a, .dropbtn {
    display: inline-block;
    color: black ;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover, .dropdown:hover .dropbtn {
    background-color: white;
}

li.dropdown {
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.dropdown-content a:hover {background-color: red ;}

.dropdown:hover .dropdown-content {
    display: block;
}

</style>
<body>


<center>
<ul >
<li style="width=280px;height:40px ;" ><b><a href="Home.html">HOME</a></b></li>
<!--<li style="width=280px;height:40px ;" ><b><a href="InsertS.html">INSERT</a></b></li> -->
 <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn"><b>INSERT</b></a>
    <div class="dropdown-content">
      <a href="InsertS.html">Sender Information</a>
      <a href="InsertR.html">Reciever Information</a>
      <a href="InsertB.html">Branch Information</a>
    </div>
  </li>
<li style="width=280px;height:40px;"><b><a href="Search.html"> SEARCH</a></b></li>
<!-- <li style="width=280px;height:40px;display=inline-block;"><a href="View.html"><b>VIEW</b></a></li> -->
<li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn"><b>VIEW</b></a>
    <div class="dropdown-content">
      <a href="ViewS.php">Sender Information</a>
      <a href="ViewR.php">Reciever Information</a>
      <a href="ViewB.php">Branch Information</a>
    </div>
  </li>
<br><br><br>


<div id="a">
<h1><center><bold><big>Search Result  Information</big> </bold></h1>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cs_db";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT * FROM sender";
$result = mysqli_query($conn, $sql);

if ($result->num_rows > 0) {
    echo "<table align=center border=1><tr><th>Name </th><th> Tag </th><th>Contact</th><th>Location</th><th>Bill</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
       echo "<tr align='center'>";
   echo"<td><font color='black'>" .$row['name']."</font></td>";
   echo"<td><font color='black'>" .$row['p_tag']."</font></td>";
   echo"<td><font color='black'>" .$row['contact']. "</font></td>";
   echo"<td><font color='black'>" .$row['location']. "</font></td>";
   echo"<td><font color='black'>" .$row['bill']. "</font></td>";

   //echo"<td></td>";
   //echo"<td></td>";

echo "</tr>";
    }
    echo "</table>";
}
else {
    echo "0 results";
}

mysqli_close($conn);
?>
 </div ><br><br><br>
 <center><button ><a href="#" id = "print" onclick= "javascript:printlayer('a')">Print </a></button></center>

   <script type = "text/javascript">
    function printlayer(layer)
    {

        var generator = window.open("", "", "width=800,height=1400");
        var layetext = document.getElementById(layer);
        generator.document.write(layetext.innerHTML.replace("Print Me"));

        generator.document.close();
        generator.print();
        generator.close();

    }
</script>
</center>
    </body>
</html>
