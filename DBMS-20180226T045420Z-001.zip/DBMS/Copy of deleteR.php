<?php

//Connecting to the mysql
$con=mysqli_connect("localhost","root","");

//Select database
 mysqli_select_db($con, 'cs_db');

//Select query
$sql = "DELETE FROM reciever WHERE name='$_GET[name]'";

//Execute the query
if (mysqli_query($con, $sql))
   header("refresh:1; url=viewR.php");
else
   echo"Not Deleted";
?>
